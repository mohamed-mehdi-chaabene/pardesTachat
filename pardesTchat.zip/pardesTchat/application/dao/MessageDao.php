<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of MessageDao
 *
 * @author delta
 */
class MessageDao {
    //put your code here
    function __construct() {
        $this->db = new DBConnexion();
    }
    /**
     * ajouter un messages
     * @param string $msg
     * @param int $_idSend
     * @param int $idDiscussion
     * @return type
     */
    public function saveMessage($msg,$_idSend,$idDiscussion) {
        $sql_msg = "INSERT INTO test_msg (id_send, id_discussion,text,date_envoie )
            VALUES (:id_send, :id_discussion,:text,NOW() )";
        $this->db->query($sql_msg, array(
            ':id_send' => $_idSend,
            ':id_discussion' => $idDiscussion,
             ':text' => $msg,
        ));
        return $this->db->getLastInsertedId();
   }

}
