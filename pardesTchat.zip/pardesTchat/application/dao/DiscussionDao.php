<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DiscussionDao
 *
 * @author delta
 */
class DiscussionDao {

    //put your code here
    /**
     * chercher tout les sg par id_envoie
     * @return array
     */
    function __construct() {
        $this->db = new DBConnexion();
    }
/**
 * chercher tous les discussion dy client connecté
 * @return array
 */
    public function getAllDiscussionByUser() {

        $adminDao = new AdminDao();
      //lister tous les membres 
        $listMembre = $adminDao->getAllWithoutUsersConnected($_SESSION['login']['id_admin']);
        $list_discussion = array();
        
        if (!empty($listMembre)) {
            foreach ($listMembre as $item) {
                 $discussion = new Discussion();
                $discussion->setReceived_name($item->getNom());
                $discussion->setReceived_id($item->getId());
                $discussion->setId($item->getId());
                //chercher une discussion par membre
                $sqlDiscussion = "SELECT * FROM test_discussion WHERE (user_id_1 = :user_conected AND  user_id_2 = :membre_id ) OR (user_id_1 = :membre_id AND  user_id_2 = :user_conected )";
                $resultDiscussion = $this->db->fetchObject($sqlDiscussion, array(':user_conected' => $_SESSION['login']['id_admin'], ':membre_id' => $item->getId()));
                //lister les messages du discussion
                if (!empty($resultDiscussion)) {
                    $sqlDiscussion = "SELECT * FROM test_msg WHERE test_msg.id_discussion=:id_discussion ORDER BY date_envoie";
                    $resultMsg = $this->db->fetchAllObjects($sqlDiscussion, array(':id_discussion' => $resultDiscussion->id));
                  $list_msg = array();  
                    if (!empty($resultMsg)) {
                        foreach ($resultMsg as $msgItem) {
                            $msg = new Massage();
                            $msg->setId($msgItem->id);
                            $msg->setText($msgItem->text);
                            $msg->setDate_envoie(($msgItem->date_envoie));
                            $msg->setId_send($msgItem->id_send);
                            if ($_SESSION['login']['id_admin'] == $msgItem->id_send)
                                $msg->setIs_send_user_connected(1);
                            else
                                $msg->setIs_send_user_connected(0);
                           array_push($list_msg, $msg); 
                        }
                        $discussion->setListe_msg($list_msg);
                    }
                }
                //le tabelau contient toute les information d'une discussion (les membres avec les messages)
               array_push($list_discussion, $discussion); 
            }
        }
        return $list_discussion;
    }
    /**
     * chercher si il existe une discussion entre deux meembre
     * @param int $idUsers1
     * @param int $idUsers2
     * @return boolean
     */
   public function findDiscussion($idUsers1,$idUsers2){
       $sqlDiscussion = "SELECT * FROM test_discussion WHERE (user_id_1 = :user_conected AND  user_id_2 = :membre_id ) OR (user_id_1 = :membre_id AND  user_id_2 = :user_conected )";
                $resultDiscussion = $this->db->fetchObject($sqlDiscussion, array(':user_conected' => $idUsers1, ':membre_id' => $idUsers2));
                if (!empty($resultDiscussion)) {
                    return $resultDiscussion->id;
                }
 else 
     return False;
   }
   /**
    * Ajouter une discussion
    * @param int $userId1
    * @param int $userId2
    * @return type
    */
   public function saveDiscussion($userId1,$userId2) {
        $sql_discussion = "INSERT INTO test_discussion (user_id_1, user_id_2 )
            VALUES (:user_id_1, :user_id_2 )";
        $this->db->query($sql_discussion, array(
            ':user_id_1' => $userId1,
            ':user_id_2' => $userId2,
           
        ));
        return $this->db->getLastInsertedId();
   }

}
