<?php

__autoload("Admin");

class AdminDao {

    private $db;
    private $droitAcccesDao;

    function __construct() {
        $this->db = new DBConnexion();
    }

    /**
     *
     * @param type $id_admin
     * @return \Admin|boolean
     */
    public function getById($id_admin) {
        $sql = "SELECT * FROM test_admin WHERE test_admin.id = :id";

        $res = $this->db->fetchObject($sql, array(':id' => $id_admin));

        if (!empty($res)) {
            $admin = new Admin();
            $admin->setId($id_admin);
            $admin->setNom($res->nom);
            $admin->setPrenom(($res->prenom));
            $admin->setEmail($res->email);
            $admin->setLogin($res->login);
            $admin->setMot_passe($res->mot_passe);
            $admin->setConnecte($res->connecte);
            $admin->setDerniere_activite($res->derniere_activite);
            $admin->setDate_demande_reinitialisation($res->date_demande_reinitialisation);
            $admin->setDemande_reinitialistation($res->demande_reinitialisation);
            $admin->setToken_reinitialisation($res->token_reinitialisation);

            return $admin;
        }
        return FALSE;
    }

    /**
     * chercher membre selon login et mot de passe
     * @param string $username
     * @param string $password
     * @return boolean
     */
    public function find($login, $mot_passe) {
        $sql = 'SELECT id, nom, prenom, email, login, mot_passe, derniere_activite, connecte, date_demande_reinitialisation,  demande_reinitialisation, token_reinitialisation FROM test_admin WHERE login = :login AND mot_passe= :mot_passe ';

        $res = $this->db->fetchObject($sql, array(':login' => $login, ':mot_passe' => md5($mot_passe)));

        if (!empty($res)) {
            $admin = new Admin();
            $admin->setId($res->id);
            $admin->setNom($res->nom);
            $admin->setPrenom(($res->prenom));
            $admin->setEmail($res->email);
            $admin->setLogin($res->login);
            $admin->setMot_passe($res->mot_passe);
            $admin->setConnecte($res->connecte);
            $admin->setDerniere_activite($res->derniere_activite);
            $admin->setDate_demande_reinitialisation($res->date_demande_reinitialisation);
            $admin->setDemande_reinitialistation($res->demande_reinitialisation);
            $admin->setToken_reinitialisation($res->token_reinitialisation);

            return $admin;
        }
        return false;
    }

    /**
     * Ajouterun admin
     * @param Admin $admin
     * @return type
     */
    public function ajouterAdmin(Admin $admin) {
        $sql_admin = "INSERT INTO test_admin ( nom, prenom, email, login, mot_passe)
            VALUES ( :nom, :prenom, :email, :login, :mot_passe)";
        $this->db->query($sql_admin, array(
            ':nom' => $admin->getNom(),
            ':prenom' => $admin->getPrenom(),
            ':email' => $admin->getEmail(),
            ':login' => $admin->getLogin(),
            ':mot_passe' => $admin->getMot_passe(),
        ));
        return $this->db->getLastInsertedId();
    }

    /**
     * chercher admin par login
     * @param type $username
     * @return boolean
     */
    public function findbylogin($username) {
        $sql = "SELECT id FROM test_admin WHERE login = :username  ";
        $res = $this->db->fetchObject($sql, array(':username' => $username));
        if (!empty($res)) {
            $admin = new Admin();
            $admin->setId($res->id);
            return $admin;
        } else
            return false;
    }

    /**
     *
     * @param type $email
     * @return \Admin|boolean
     */
    public function getByEmail($email) {
        $sql = "SELECT id, nom, prenom ,login, mot_passe, derniere_activite, connecte FROM test_admin WHERE email = :email ";
        if (!empty($res)) {

            $admin = new Admin();
            $admin->setId($res->id);
            $admin->setNom($res->nom);
            $admin->setPrenom(($res->prenom));
            $admin->setLogin($res->login);
            $admin->setMot_passe($res->mot_passe);
            $admin->setDerniere_activite($res->derniere_activite);
            $admin->setConnecte($res->connecte);
            return $admin;
        }
        return FALSE;
    }

    /**
     * chercher tout administrateur active sauf le contact connecté
     * @return array
     */
    public function getAllWithoutUsersConnected($usersId) {
        $sql = "SELECT * FROM test_admin WHERE id != :id";
        $resultList = $this->db->fetchAllObjects($sql, array(':id' => $usersId));
        $list_admin = array();
        if (!empty($resultList)) {
            foreach ($resultList as $item) {
                $admin = new Admin();
                $admin->setId($item->id);
                $admin->setNom($item->nom);
                $admin->setPrenom(($item->prenom));
                $admin->setLogin($item->login);
                $admin->setMot_passe($item->mot_passe);
                $admin->setDerniere_activite($item->derniere_activite);
                $admin->setConnecte($item->connecte);
                $admin->setEmail($item->email);

                array_push($list_admin, $admin);
            }
        }
        return $list_admin;
    }

    /**
     * mis ajour la date de connexion et activité de l'id connecté
     * @param int $id
     */
    public function enregistrerConnexion($id) {
        $sql = "UPDATE test_admin SET derniere_activite= NOW(), connecte= 1 WHERE id = :id";
        $this->db->query($sql, array(':id' => $id));
    }

    /**
     * mis ajour la date de connexion et activité de l'id connecté
     * @param int $id
     */
    public function enregistrerDeConnexion($id) {
        $sql = "UPDATE test_admin SET derniere_activite= NOW(), connecte= 0 WHERE id = :id";
        $this->db->query($sql, array(':id' => $id));
    }

}

?>
