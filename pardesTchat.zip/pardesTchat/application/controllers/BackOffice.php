<?php

__autoload("Admin");
__autoload("AdminDao");
__autoload("DiscussionDao");

class BackOffice {

    private $adminDao;

    function __construct() {
        session_start();
    }

    function index() {
        if ($this->verifierSesssion()) {
            header("location:" . SITE_PATH . "admin/tableauBord");
            exit();
        }
        Router::render_view("admin/index");
    }

    /**
     * appel ajax ,envoie de message entre deux memebres
     */
    function envoyerMsg() {
        //echo"here";die();
        // echo($_POST['idReceived']);die();
        $discusionDao = new DiscussionDao();
        $msgDao = new MessageDao();
        $idDiscussion = $discusionDao->findDiscussion($_POST['idReceived'], $_SESSION['login']['id_admin']);
        if ($idDiscussion) {
            //save msg
            $idMsg = $msgDao->saveMessage($_POST['msg'], $_SESSION['login']['id_admin'], $idDiscussion);
        } else {
            //save discussion
            $idDiscussion = $discusionDao->saveDiscussion($_POST['idReceived'], $_SESSION['login']['id_admin']);
            //save msg
            $idMsg = $msgDao->saveMessage($_POST['msg'], $_SESSION['login']['id_admin'], $idDiscussion);
        }
        echo json_encode($idMsg);
    }

    /**
     * Céation du compte
     */
    function registrer() {
        $autoriser_connexion = FALSE;
        $this->adminDao = new AdminDao();
        $error = FALSE;
// tester la valideté des données postés
        if (isset($_POST['registrer'])) {
            if ((!isset($_POST['login_admin']) || strlen($_POST['login_admin']) == 0) || (!isset($_POST['pwd_admin']) || strlen($_POST['pwd_admin']) == 0)) {
//messages d'erreurs
                $error = "Merci de renseigner tous les champs obligatoires.";
            } else {
                $existence_admin = $this->adminDao->findbylogin($_POST['login_admin']);

                if ($existence_admin)
                    $error = "login déja existe.";
                else {
// ajouter utilisateurs
                    $autoriser_connexion = TRUE;
                    $adminDao = new AdminDao();
                    $user = new Admin();
                    $user->setEmail($_POST['email_admin']);
                    $user->setNom($_POST['nom_admin']);
                    $user->setPrenom($_POST['prenom_admin']);
                    $user->setLogin($_POST['login_admin']);
                    $user->setMot_passe(md5($_POST['pwd_admin']));
                    $idAdmin = $adminDao->ajouterAdmin($user);

// tester si l'admin est active ou non
                    if ($autoriser_connexion) {
// Intialisation des variables  Session
                        unset($_SESSION['login']);
                        $_SESSION['login']['id_admin'] = $idAdmin;
                        $_SESSION['login']['nom_admin'] = $_POST['nom_admin'];
                        $_SESSION['login']['prenom_admin'] = $_POST['prenom_admin'];
                        $_SESSION['login']["email_admin"] = $_POST['email_admin'];

                        $adminDao->enregistrerConnexion($idAdmin);
// Redirection vers la page desmessages
                        header("Location:" . SITE_PATH . "admin/tableauBord");
                        exit();
                    } else {
                        $error = "Vous n'avez pas les autorisations nécessaires pour accéder à cette page.";
                    }
                }
            }
        }
        $data = array("error" => $error);
        Router::render_view("admin/index", $data);
    }

    /**
     * authentifcation
     */
    function login() {
        $this->adminDao = new AdminDao();

        $error = FALSE;
// tester la valideté des données postés
        if (isset($_POST['connexion'])) {
            if ((!isset($_POST['login']) || strlen($_POST['login']) == 0) || (!isset($_POST['password']) || strlen($_POST['password']) == 0)) {
//messages d'erreurs
                $error = "Merci de renseigner tous les champs obligatoires.";
            } else {
// chercher correspondance dans la BD

                $adminDao = new AdminDao();

                $admin = $adminDao->find($_POST['login'], $_POST['password']);

                if ($admin) {

// Intialisation des variables  Session
                    unset($_SESSION['login']);
                    $_SESSION['login']['id_admin'] = $admin->getId();
                    $_SESSION['login']['nom_admin'] = $admin->getNom();
                    $_SESSION['login']['prenom_admin'] = $admin->getPrenom();
                    $_SESSION['login']["email_admin"] = $admin->getEmail();

                    $adminDao->enregistrerConnexion($admin->getId());


// Redirection vers la page embasement
                    header("Location:" . SITE_PATH . "admin/tableauBord");
                    exit();
                } else {
//Messages d'erreur champs invalides dans le formualire de connexion
                    $error = "Merci de vérifier la saisie de vos informations.";
                }
            }
        }
        $data = array("error" => $error);
        Router::render_view("admin/index", $data);
    }

    /**
     * Vérification de session , déconnexion si on dépansse un temps précis
     */
    function verifierSesssion() {
        $this->adminDao = new AdminDao();
        $_SESSION_TIMEOUT = 900;
        $id_admin = $_SESSION['login']['id_admin'];
        $admin = $this->adminDao->getById($id_admin);
        $derniere_activite = $admin->getDerniere_activite();
        $now = (date('Y/d/m h:i:s'));
        $adminDao = new AdminDao();

        if (DECONNEXION_AUTO) {
            if (($derniere_activite && ($now - time($derniere_activite) > $_SESSION_TIMEOUT))) {
                $this->adminDao->enregistrerDeConnexion($admin->getId());

                session_unset();
                session_destroy();
                header("location:" . SITE_PATH . "admin/login");
                exit();
            } else {
                $adminDao->enregistrerConnexion($id_admin);
            }
        } else {
            $adminDao->enregistrerConnexion($id_admin);
        }
    }

    /**
     * Déconnexion
     */
    function logout() {
//#recuperer l'id admin de la session
        $id_admin = $_SESSION['login']['id_admin'];

        $adminDao = new AdminDao();
        $adminDao->enregistrerDeConnexion($id_admin);
// supprimer la session
        session_unset();
        session_destroy();
// redirection vers la page login
        header("location:" . SITE_PATH . "admin/login");
        exit();
    }

    /**
     * tableau de bord qui contient les messages archivé 
     */
    function tableauBord() {

        $this->verifierSesssion();
        $id = $_SESSION["login"]["id_admin"];
        $this->discussionDao = new DiscussionDao();
        $liste_discussion = $this->discussionDao->getAllDiscussionByUser();
        $data = array(
            'liste_discussion' => $liste_discussion,
        );
        Router::render_view("admin/tableau_bord", $data);
    }

    /**
     * Erreur Access
     */
    public function ErreurPasAcces() {
        Router::render_view("admin/erreur_pas_acces");
    }

    /**
     * lister les membres avec les statuts (connecté ou non )
     */
    function gestionMembre() {
        $this->adminDao = new AdminDao();
        $this->verifierSesssion();
        $list_admin = $this->adminDao->getAllWithoutUsersConnected($_SESSION['login']['id_admin']);
        $data = array(
            'list_admin' => $list_admin,
        );
        Router::render_view("admin/gestion_membres", $data);
    }

}

?>
