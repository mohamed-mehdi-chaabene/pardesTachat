<html>
    <head>
        <meta charset="utf-8"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
        <title>Tchat Pardes</title>
        <meta name="description" content=""/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->

        <!--base css styles-->
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css"/>
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css"/>

        <!--page specific css styles-->

        <!--flaty css styles-->
        <link rel="stylesheet" href="css/flaty.css"/>
        <link rel="stylesheet" href="css/flaty-responsive.css"/>

        <link rel="shortcut icon" href="images/favicon.ico"/>
    </head>
    <body class="login-page">


        <!-- BEGIN Main Content -->
        <div class="login-wrapper">
            <!-- BEGIN Login Form -->
            <form id="loginform" action="login" method="post">
                <h3> <center>	<img src="images/logo.jpg" /> </center></h3>
                <hr/>
                <?php  if (!empty($msg_success)) { ?>
                    <div class="alert alert-success">
                        <button data-dismiss="alert" class="close"></button>
                        <strong>Succès!</strong> <?= $msg_success ?>
                    </div>


                <?php  } ?>

                <?php  if (!empty($error)) { ?>

                    <div class="alert alert-danger">
                        <button data-dismiss="alert" class="close"></button>
                        <strong>Erreur!</strong>   <?php  echo $error; ?>
                    </div>
                    <br />
                <?php } ?>


                <div class="form-group">
                    <div class="controls">
                        <input type="text"name="login"  placeholder="Nom d'utilisateur" class="form-control" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="controls">
                        <input type="password" name="password" placeholder="Mot de passe" class="form-control" />
                    </div>
                </div>

                <div class="form-group">
                    <div class="controls">
                        <button  type="submit" name="connexion" class="btn btn-primary form-control">Connexion</button>
                    </div>
                </div>
                <hr/>
               
                 <p class="clearfix">
                    <a href="#form-register" class="goto-register pull-left">S'identifier</a>                  
                </p>
            </form>
           
            <!-- BEGIN Forgot Password Form -->
            <form id="form-forgot" action="recupererPassword" method="Post" style="display:none">
                <h3>Récupérer votre mot de passe</h3>
                <hr/>

                <div class="form-group">
                    <div class="controls">
                        <input type="text" placeholder="Login" name="login_admin" class="form-control" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="controls">
                        <button type="submit"  name="submit" class="btn btn-primary form-control">Récupérer</button>
                    </div>
                </div>
                <hr/>
                <p class="clearfix">
                    <a href="index" class="goto-login pull-left">← Retour</a>
                </p>
            </form>
            <!-- BEGIN Forgot Password Form -->
             <form id="form-register" action="registrer" method="Post" style="display:none">
                <h3>Inscrire</h3>
                <hr/>

                <div class="form-group">
                    <div class="controls">
                        <input type="text" placeholder="Nom" name="nom_admin" class="form-control" data-rule-required="true"/>
                    </div>
                </div>
                <div class="form-group">
                    <div class="controls">
                        <input type="text" placeholder="Prenom" name="prenom_admin" class="form-control" data-rule-required="true" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="controls">
                        <input type="text" placeholder="login" name="login_admin" data-rule-required="true" class="form-control" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="controls">
                        <input type="password"  placeholder="Mot de passe" name="pwd_admin" data-rule-required="true" class="form-control" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="controls">
                        <input type="email"  placeholder="Email" name="email_admin" class="form-control" data-rule-required="true" data-rule-email="true" />
                    </div>
                </div>
                <div class="form-group">
                    <div class="controls">
                        <button type="submit"  name="registrer" class="btn btn-primary form-control">S'inscrire</button>
                    </div>
                </div>
                <hr/>
                <p class="clearfix">
                    <a href="index" class="goto-login pull-left">← Retour</a>
                </p>
            </form>
            <!-- END Forgot Password Form -->

            <!-- BEGIN Register Form -->

            <!-- END Register Form -->

        </div>
        <!-- END Main Content -->

        <!--basic scripts-->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="assets/jquery/jquery-2.0.3.min.js"><\/script>')</script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>

        <script type="text/javascript">
            function goToForm(form)
            {
                $('.login-wrapper > form:visible').fadeOut(500, function() {
                    $('#form-' + form).fadeIn(500);
                });
            }
            
                $(function() {
                    $('.goto-login').click(function() {
                        goToForm('login');
                    });
                    $('.goto-forgot').click(function() {
                        goToForm('forgot');
                    });
                    $('.goto-register').click(function() {
                        goToForm('register');
                    });
                });
           
        </script>
    </body>
</html>
