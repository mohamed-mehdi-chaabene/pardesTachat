<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Pardes</title>
        <meta name="description" content=""/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css"/>
        <link rel="stylesheet"href="assets/font-awesome/css/font-awesome.min.css"/>
        <link rel="stylesheet" href="assets/data-tables/bootstrap3/dataTables.bootstrap.css" />
        <!--page specific css styles-->
        <link rel="stylesheet" href="assets/gritter/css/jquery.gritter.css"/>
        <link rel="stylesheet" href="css/flaty.css"/>
        <link rel="stylesheet" href="css/flaty-responsive.css"/>
        <link rel="stylesheet" href="css/style.css"/>
        <link rel="shortcut icon" href="images/favicon.ico"/>
    </head>
    <body>
        <?php include 'inc/header.php'; ?>
        <div class="container" id="main-container">
            <?php include 'inc/menu_droite.php'; ?>
            <div id="main-content">
                <!-- BEGIN Page Title -->
                <div class="page-title">
                    <div>
                        <h1>
                            <i class="glyphicon glyphicon-user"></i> Message archivés
                        </h1>
                    </div>
                </div>
                <div id="breadcrumbs">
                    <ul class="breadcrumb">
                        <li><i class="glyphicon glyphicon-user"></i> <a href="####">Message archivés</a>

                        </li>
                    </ul>
                </div>
                               

                
                    <?php       $nbre_row=0;             foreach ($liste_discussion as $discussion) {
                        $nbre_row= $nbre_row+1;
                                if(($nbre_row % 3)==1 ) {  ?>
                <div class="row">
                                <?php }  ?>
                     <div class="col-md-4">
        <!--chat start-->
        
                <div class="container">
    <div class="row chat-window col-xs-5 col-md-3" id="chat_window_1" style="margin-left:10px;">
        <div class="col-xs-12 col-md-12">
        	<div class="panel panel-default">
                <div class="panel-heading top-bar">
                    <div class="col-md-8 col-xs-8">
                        <h3 class="panel-title"><span class="glyphicon glyphicon-comment"></span> Chat -<?php echo $discussion->getReceived_name() ?></h3>
                    </div>
                    <div class="col-md-4 col-xs-4" style="text-align: right;">
                        <a href="#"><span id="minim_chat_window" class="glyphicon glyphicon-minus icon_minim"></span></a>
                        <a href="#"><span class="glyphicon glyphicon-remove icon_close" data-id="chat_window_1"></span></a>
                    </div>
                </div>
                <div class="panel-body msg_container_base">
                 <?php                 
                 if(!empty($discussion->getliste_msg())){
                 foreach ($discussion->getliste_msg() as $msg) { ?>   
                    <?php if($msg->getIs_send_user_connected()==1)
                    { $class="sent";
                    $img="http://www.bitrebels.com/wp-content/uploads/2011/02/Original-Facebook-Geek-Profile-Avatar-1.jpg";
                    }
                    else {
                   $class="receive";
                    $img="http://www.bitrebels.com/wp-content/uploads/2011/02/Original-Facebook-Geek-Profile-Avatar-1.jpg";     
                    }
                       ?>
                   
                    <div class="row msg_container base_<?php echo $class ?>">
                        <div class="col-md-10 col-xs-10">
                            <div class="messages msg_<?php echo $class ?>">
                                <p><?php echo $msg->getText(); ?></p>
                                <time datetime="<?php echo $msg->getDate_envoie(); ?>"></time>
                            </div>
                        </div>
                        <div class="col-md-2 col-xs-0 avatar">
                            <img src="<?php echo $img ?>" class=" img-responsive ">
                        </div>
                    </div>
                         
                 <?php } 
                 }?>
                     <div id="list-msg-<?php echo $discussion->getReceived_id() ?>">
                    </div>
                  
                </div>
                <div class="panel-footer">
                    <div class="input-group">
                        <input id="btn-input-<?php echo $discussion->getReceived_id() ?>" type="text" class="form-control input-sm chat_input" placeholder="Ecrire votre message içi..." />
                        <span class="input-group-btn">
                        <button class="btn btn-primary btn-sm btn-chat" id="btn-chat-<?php echo $discussion->getReceived_id() ?>">Envoyer</button>
                        </span>
                    </div>
                </div>
    		</div>
        </div>
    </div>
                    </div>
        </div>
                    <?php  if((($nbre_row % 3)==0)) { ?>
                </div>
                                <?php }  ?>
                    
                    <?php } ?>
   

            
        
        <!--chat end-->
                                
                
                
          
            </div>
        </div>
      
        <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
        <script>
            window.jQuery || document.write('<script src="assets/jquery/jquery-2.0.3.min.js"><\/script>')
        </script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/nicescroll/jquery.nicescroll.min.js"></script>
        <script src="assets/jquery-cookie/jquery.cookie.js"></script>

        <!--page specific plugin scripts-->
        <script type="text/javascript"  src="assets/data-tables/jquery.dataTables.js"></script>
        <script type="text/javascript"   src="assets/data-tables/bootstrap3/dataTables.bootstrap.js"></script>
        <script type="text/javascript"  src="js/chat.js"></script>
        
        <script>
            $(document).ready(function() {
                $("#menu_principal_users").addClass('active');
            });</script>
        <script src="assets/gritter/js/jquery.gritter.js"></script>
        <!--flaty scripts-->
        <script src="js/flaty.js"></script>
        <script src="js/function_admin.js"></script>
        <script type="text/javascript">
            $(window).resize(function() {
                iniresize();
            });
        </script>
    </body>
</html>