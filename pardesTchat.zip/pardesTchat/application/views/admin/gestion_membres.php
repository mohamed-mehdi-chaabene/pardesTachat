<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Pardes</title>
        <meta name="description" content=""/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css"/>
        <link rel="stylesheet"href="assets/font-awesome/css/font-awesome.min.css"/>
        <link rel="stylesheet" href="assets/data-tables/bootstrap3/dataTables.bootstrap.css" />
        <!--page specific css styles-->
        <link rel="stylesheet" href="assets/gritter/css/jquery.gritter.css"/>
        <link rel="stylesheet" href="css/flaty.css"/>
        <link rel="stylesheet" href="css/flaty-responsive.css"/>
        <link rel="stylesheet" href="css/style.css"/>
        <link rel="shortcut icon" href="images/favicon.ico"/>
    </head>
    <body>
        <?php include 'inc/header.php'; ?>
        <div class="container" id="main-container">
            <?php include 'inc/menu_droite.php'; ?>
            <div id="main-content">
                <!-- BEGIN Page Title -->
                <div class="page-title">
                    <div>
                        <h1>
                            <i class="glyphicon glyphicon-user"></i> Membres
                        </h1>
                    </div>
                </div>
                <div id="breadcrumbs">
                    <ul class="breadcrumb">
                        <li><i class="glyphicon glyphicon-user"></i> <a href="####">Gestion des memebres</a>

                        </li>
                    </ul>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="box box-black">
                            <div class="box-title">
                                <h3>
                                    <i class="icon-table"></i> Liste des mmebres
                                </h3>
                                <div class="box-tool">
                                    <a data-action="collapse" href="#"><i class="icon-chevron-up"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="box-content">
                               
                                <div class="btn-toolbar pull-right">
                                    <div class="btn-group">
                                        
                                    </div>
                                </div>
                                <br /> <br />
                                <div class="table-responsive">
                                    <table class="table table-advance" id="table_membre">
                                        <thead>
                                            <tr>
                                                <th>Nom</th>
                                                <th>Prénom</th>
                                                <th>Connecté</th>
                                           
                                         
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($list_admin as $item) { ?>
                                                <tr id="<?= $item->getId() ?>">
                                                    <td>
                                                        <?= $item->getNom(); ?>
                                                    </td>
                                                    <td>
                                                        <?= $item->getPrenom(); ?>
                                                    </td>
                                                    <td >
                                                        <?php if ($item->getconnecte() == 1) { ?>
                                                            <span style="display: none">1</span>
                                                            <img src="images/status-active.png" border="0" style="width: 4% !important;" />
                                                        <?php } else { ?>
                                                            <span style="display: none">0</span>
                                                            <img src="images/status-inactive.png" border="0" style="width: 4% !important;" />
                                                        <?php } ?>
                                                    </td>
                                                    
                                                    
                                                </tr>
                                            <?php } ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <footer>
                   
                </footer>
                <a id="btn-scrollup" class="btn btn-circle btn-lg" href="#"><i class="icon-chevron-up"></i></a>
            </div>
        </div>
        
        <script src="//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
        <script>
            window.jQuery || document.write('<script src="assets/jquery/jquery-2.0.3.min.js"><\/script>')
        </script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/nicescroll/jquery.nicescroll.min.js"></script>
        <script src="assets/jquery-cookie/jquery.cookie.js"></script>

        <!--page specific plugin scripts-->
        <script type="text/javascript"  src="assets/data-tables/jquery.dataTables.js"></script>
        <script type="text/javascript"   src="assets/data-tables/bootstrap3/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function() {
                $("#menu_principal_users").addClass('active');
            });</script>
        <script src="assets/gritter/js/jquery.gritter.js"></script>
        <!--flaty scripts-->
        <script src="js/flaty.js"></script>
        <script src="js/function_admin.js"></script>
        <script type="text/javascript">
            $(window).resize(function() {
                iniresize();
            });
        </script>
    </body>
</html>