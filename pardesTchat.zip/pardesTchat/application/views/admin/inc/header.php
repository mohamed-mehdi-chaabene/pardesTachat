<div class="headerspace"></div>
<div id="navbar" class="navbar">
    <button type="button" class="navbar-toggle navbar-btn collapsed"
            data-toggle="collapse" data-target="#sidebar">
        <span class="icon-reorder"></span>
    </button>
    <a class="navbar-brand" href="tableauBord"> <small class="small-header">
            <i class="icon-image" style="margin-top: -4px;"></i>
            <label style="margin-top: -28px; margin-left: 40px;"class="col-sm-8 col-lg-12 col-lg-offset-1 " for="username" id="headername">
                
            </label>
        </small>
    </a>
    <ul class="nav flaty-nav pull-right">

      
        <li class="user-profile">
            <a data-toggle="dropdown" href="#" class="user-menu dropdown-toggle">
                <img class="nav-user-photo" src="images/logo.png" alt="<?php echo($_SESSION['login']['nom_admin']); ?>" />
                <span class="hidden-sm" id="user_info"> <?php echo($_SESSION['login']['nom_admin']); ?></span>
                <i class="icon-caret-down"></i>
            </a>
            <ul class="dropdown-menu dropdown-navbar" id="user_menu">
                
                <li class="divider"></li>
                <li>
                    <a href="logout">
                        <i class="icon-off"></i> Déconnexion
                    </a>
                </li>
            </ul>
        </li>
    </ul>
</div>