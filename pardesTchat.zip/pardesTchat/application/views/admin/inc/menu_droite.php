<div id="sidebar" class="navbar-collapse collapse" >
    <ul class="nav nav-list" style="margin-top: 14px;">
        <li id="tableau_bord"  class="active" >
            <a href="tableauBord">
                <i class="icon-dashboard"></i>
                <span>Message archivés</span>
            </a>
        </li>
        
                 
       
            <li class="active" >
                <a href="gestionMembre">
                    <i class="glyphicon glyphicon-user"></i>
                    <span>Gestion des memebres</span>
                </a>
            </li>
      
    </ul>
    <div id="sidebar-collapse" class="visible-lg">
        <i class="icon-double-angle-left"></i>
    </div>
</div>
