<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Discussion
 *
 * @author Mehdi
 */
class Discussion {
    //colonne
    private $id;
    private $user_id_1;
    private $user_id_2;
    //flag
    private $received_name;
    private $received_id;
    private $liste_msg;
    public function getId() {
        return $this->id;
    }

    public function getUser_id_1() {
        return $this->user_id_1;
    }

    public function getUser_id_2() {
        return $this->user_id_2;
    }

    public function getReceived_name() {
        return $this->received_name;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setUser_id_1($user_id_1) {
        $this->user_id_1 = $user_id_1;
    }

    public function setUser_id_2($user_id_2) {
        $this->user_id_2 = $user_id_2;
    }

    public function setReceived_name($received_name) {
        $this->received_name = $received_name;
    }
    public function getListe_msg() {
        return $this->liste_msg;
    }

    public function setListe_msg($liste_msg) {
        $this->liste_msg = $liste_msg;
    }
    public function getReceived_id() {
        return $this->received_id;
    }

    public function setReceived_id($received_id) {
        $this->received_id = $received_id;
    }






}
