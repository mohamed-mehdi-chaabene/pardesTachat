<?php

/**
 * Description of Admin
 *
 * 
 * 
 */
class Admin {


    private $id;
    private $nom;
    private $prenom;
    private $email;
    private $login;
    private $mot_passe;
    private $derniere_activite;
    private $connecte;
    private $demande_reinitialistation;
    private $date_demande_reinitialisation;
    private $token_reinitialisation;

    public function getId() {
        return $this->id;
    }

    public function setId($id) {
        $this->id = $id;
    }


    public function getNom() {
        return $this->nom;
    }

    public function setNom($nom) {
        $this->nom = $nom;
    }

    public function getPrenom() {
        return $this->prenom;
    }

    public function setPrenom($prenom) {
        $this->prenom = $prenom;
    }

    public function getEmail() {
        return $this->email;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function getLogin() {
        return $this->login;
    }

    public function setLogin($login) {
        $this->login = $login;
    }

    public function getMot_passe() {
        return $this->mot_passe;
    }

    public function setMot_passe($mot_passe) {
        $this->mot_passe = $mot_passe;
    }

    public function getDerniere_activite() {
        return $this->derniere_activite;
    }

    public function setDerniere_activite($derniere_activite) {
        $this->derniere_activite = $derniere_activite;
    }

    public function getConnecte() {
        return $this->connecte;
    }

    public function setConnecte($connecte) {
        $this->connecte = $connecte;
    }

    public function getDemande_reinitialistation() {
        return $this->demande_reinitialistation;
    }

    public function setDemande_reinitialistation($demande_reinitialistation) {
        $this->demande_reinitialistation = $demande_reinitialistation;
    }

    public function getDate_demande_reinitialisation() {
        return $this->date_demande_reinitialisation;
    }

    public function setDate_demande_reinitialisation($date_demande_reinitialisation) {
        $this->date_demande_reinitialisation = $date_demande_reinitialisation;
    }

    public function getToken_reinitialisation() {
        return $this->token_reinitialisation;
    }

    public function setToken_reinitialisation($token_reinitialisation) {
        $this->token_reinitialisation = $token_reinitialisation;
    }

   

    

    

   

   

   

}

?>
