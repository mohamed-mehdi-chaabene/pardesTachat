<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Massage
 *
 * @author mehdi
 */
class Massage {
    
    private $id;
    private $id_send;
    private $id_discussion;
    private $text;
    private $date_envoie;
    //flag
    private $is_send_user_connected;
    public function getId() {
        return $this->id;
    }

    public function getId_send() {
        return $this->id_send;
    }

    public function getText() {
        return $this->text;
    }

    public function getDate_envoie() {
        return $this->date_envoie;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setId_send($id_send) {
        $this->id_send = $id_send;
    }

    public function getId_discussion() {
        return $this->id_discussion;
    }

    public function setId_discussion($id_discussion) {
        $this->id_discussion = $id_discussion;
    }

    
    public function setText($text) {
        $this->text = $text;
    }

    public function setDate_envoie($date_envoie) {
        $this->date_envoie = $date_envoie;
    }
    public function getIs_send_user_connected() {
        return $this->is_send_user_connected;
    }

    public function setIs_send_user_connected($is_send_user_connected) {
        $this->is_send_user_connected = $is_send_user_connected;
    }




}
