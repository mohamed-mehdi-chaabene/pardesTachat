<?php

/**
 * Description of DBConnexion
 *
 * @author Mohamed mehdi chaabene
 */
class DBConnexion {
    protected static $instance = null;
    //# retourner l'instance en cours
    public static function instance() {
        if (self::$instance === null) {
            try {
                self::$instance = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME, DB_USER, DB_PASSWORD);
                self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            } catch (PDOException $e) {
                die($e->getMessage());
            }
        }
        return self::$instance;
    }
    //# exécuter requête sans retourner de résultat
    public static function query($query, $values = NULL) {
        try {
            $pre = self::instance()->prepare($query);
            if (isset($values))
                $pre->execute($values);
            else
                $pre->execute();
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }

    //# retourner une seule ligne
    public static function fetchObject($query, $values = NULL) {
        try {
            $pre = self::instance()->prepare($query);
            if (isset($values))
                $pre->execute($values);
            else
                $pre->execute();
            return $pre->fetch(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }

    //# retourner plusieurs lignes
    public static function fetchAllObjects($query, $values = NULL) {
        try {
            $pre = self::instance()->prepare($query);
            if (isset($values))
                $pre->execute($values);
            else
                $pre->execute();
            return $pre->fetchAll(PDO::FETCH_OBJ);
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }

    //# calcul de nombre de lignes
    public static function count($query, $values = NULL) {
        try {
            $pre = self::instance()->prepare($query);
            if (isset($values))
                $pre->execute($values);
            else
                $pre->execute();
            return $pre->rowCount();
        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }

    //# last inserted id
    public function getLastInsertedId() {
        return self::instance()->lastInsertId();
    }

     public function quote($string) {
        return self::instance()->quote($string);
    }

}

?>
