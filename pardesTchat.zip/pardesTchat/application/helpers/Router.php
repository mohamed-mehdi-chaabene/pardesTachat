<?php

class Router {

    static function route() {
        //# extraire URL
        if (PROJECT == "/")
            $base_url = substr($_SERVER["REQUEST_URI"], 1);
        else
            $base_url = str_replace(PROJECT, "", $_SERVER["REQUEST_URI"]);

        $url_extract = array();
        if (strpos($base_url, "?") > 0)
            $url_extract = explode("?", $base_url);
        if (count($url_extract) > 0)
            $base_url = $url_extract[0];
        $url_pieces = explode("/", $base_url);
        //# controlleur
        $route_controller = "index";
        if (!empty($url_pieces[0]))
            $route_controller = $url_pieces[0];


            //# routage standart pour les autres contrôlleurs
            //# l'action à exécuter correspond tjs dans ce cas à la deuxième partie (index = 1= extraite dans l'url
            $action = "index";
            if (count($url_pieces) > 1) {
                if (!empty($url_pieces[1]))
                    $action = $url_pieces[1];
            }

            //# vérifier l'existance du controlleur dans le tableau de routage
            if (isset($GLOBALS['routes'][$route_controller])) {
                $controller = $GLOBALS['routes'][$route_controller];
                Router::perform_controller_action($controller, $action);
            }
        

        //# rediriger en cas d'erreur
        error_404();
    }

    static function perform_controller_action($controller, $action, array $params = NULL, $constuctor_with_params = FALSE) {
        $controller_path = "application/controllers/" . $controller . ".php";
        if (file_exists($controller_path)) {

            require_once $controller_path;
            if (!method_exists($controller, $action)) {
                error_404();
            }

            //# créer instance de la classe controlleur
            if ($constuctor_with_params)
                $instance = new $controller($params);
            else
                $instance = new $controller();
            $instance->$action($params);
            exit;
        }
        error_404();
        exit;
    }

    /**
     *
     * @param type $view
     * @param array $variables
     * @return boolean
     */
    static function render_view($view, array $variables = NULL) {
        $view_path = "application/views/" . $view . ".php";
        if (file_exists($view_path)) {
            if ($variables) {
                extract($variables);
            }
            include $view_path;
            return true;
        }
        return false;
    }

}

?>