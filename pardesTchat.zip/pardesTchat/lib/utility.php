<?php



function error_404() {
    header('location: ' . SITE_PATH . 'erreur/');
    exit;
}

function fatal_error($error) {
    die("Erreur fatale: $error");
}
/**
 * appele des class
 * @param type $class
 * @return type
 */
function __autoload($class) {
    $directorys = array(
        'application/helpers/',
        'application/models/',
        'application/controllers/',
        'application/dao/'
    );

    foreach ($directorys as $directory) {

        if (file_exists($directory . $class . '.php')) {
            require_once($directory . $class . '.php');
            return;
        }
    }
    fatal_error("Impossible de trouver la classe '$class'");
}



?>
