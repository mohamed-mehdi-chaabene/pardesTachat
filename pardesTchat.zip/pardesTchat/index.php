<?php
//autorisation requete ajax distante
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Max-Age: 1000');

if (array_key_exists('HTTP_ACCESS_CONTROL_REQUEST_HEADERS', $_SERVER)) {
    header('Access-Control-Allow-Headers: '
            . $_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']);
} else {
    header('Access-Control-Allow-Headers: *');
}

require_once 'config/config_dev.php';
require_once 'config/config.php';
require_once 'config/routes.php';
require_once 'lib/utility.php';

__autoload("Router");
__autoload("DBConnexion");

Router::route();
?>
