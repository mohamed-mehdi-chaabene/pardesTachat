<?php

//# afficher tous les erreurs
//error_reporting(E_ALL);
error_reporting(E_ALL ^ E_NOTICE);
ini_set('display_errors', '1');
//# ne pas coupé l'exécution des script
ignore_user_abort(true);
set_time_limit(0);
define('DEV_ENV', 'dev');

define('SITE_PATH', "http://localhost/pardesTchat/");

define('PROJECT', "/pardesTchat/");

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'bd_pardes_tchat');








