<?php
$GLOBALS['routes'] = array('admin' => 'BackOffice');

?>
