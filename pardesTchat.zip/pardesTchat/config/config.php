<?php
//# BACK OFFICE
define('DECONNEXION_AUTO', TRUE);

?>
